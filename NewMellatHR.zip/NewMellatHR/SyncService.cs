﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Timers;

namespace NewMellatHR
{
    partial class SyncService : ServiceBase
    {
        public SyncService()
        {
            InitializeComponent();
        }
        Timer t = new Timer();
        protected override void OnStart(string[] args)
        {
            t.Interval = 3600000;
            t.Elapsed += t_Elapsed;
            try
            {
                Update();
            }
            catch (Exception)
            {

                
            }
            // TODO: Add code here to start your service.
        }

        void t_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (DateTime.Now.Hour == 10)
                Update();
            
        }
        public void Update()
        {
            HrService.PRSClient prsClient = new HrService.PRSClient();

            ProjectServer_Reporting_faEntities entities = new ProjectServer_Reporting_faEntities();
            var data = from emp in entities.MSP_EpmResource_UserView where emp.کد_پرسنلی != null select emp.کد_پرسنلی;
            foreach (var empCode in data)
            {
                int empId = 0;
                if (!int.TryParse(empCode.Trim(), out empId))
                    continue;
                try
                {
                    var pm = prsClient.getEmployeeSpec(empId, "20", "epm2", "E123456");
                    if (pm.PersonCode == null)
                        continue;
                    var hrEmployee = (from hrEmp in entities.HrEmployeeDetails where hrEmp.EmployeeCode == empId select hrEmp).FirstOrDefault();
                    if (hrEmployee == null)
                    {
                        
                        hrEmployee = new HrEmployeeDetail
                        {
                            EmployeeCode = empId,
                            FirstName = pm.FName,
                            LastName = pm.LName,
                            Status = pm.PrsVazKhedmatName,
                            StatusCode = pm.PrsVazKhedmaTCode,
                            Department = pm.DepTitle,
                            DepartmentCode = (int)(pm.DPCode ?? 0),
                            Unit = pm.UnitName,
                            UnitCode = (int)(pm.UnitCode ?? 0),
                            Sex=pm.GenderName,
                            



                        };
                        entities.HrEmployeeDetails.Add(hrEmployee);

                    }
                    else
                    {
                        hrEmployee.FirstName = pm.FName;
                        hrEmployee.LastName = pm.LName;
                        hrEmployee.Status = pm.PrsVazKhedmatName;
                        hrEmployee.StatusCode = pm.PrsVazKhedmaTCode;
                        hrEmployee.Department = pm.DepTitle;
                        hrEmployee.DepartmentCode = (int)(pm.DPCode ?? 0);
                        hrEmployee.Unit = pm.UnitName;
                        hrEmployee.UnitCode = (int)(pm.UnitCode ?? 0);
                    }
                    entities.SaveChanges();

                }
                catch (Exception ex)
                {
                    File.AppendAllText(@"D:\Projects\Log.txt", ex.ToString() + "\n---------------------------------\n");
                }

            }


        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }
    }
}
